//
//  Company.swift
//  WendelDaniel_CE03
//
//  Created by Daniel Wendel on 5/6/21.
//

import Foundation

class Company{
    var company : String
    var name : String
    var version : String
    
    
    
    
    init(company : String, name : String, version : String) {
        self.company = company
        self.name = name
        self.version = version
        
    }

}
