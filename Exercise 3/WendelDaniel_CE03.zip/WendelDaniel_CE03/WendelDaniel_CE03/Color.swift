//
//  Color.swift
//  WendelDaniel_CE03
//
//  Created by Daniel Wendel on 5/6/21.
//

import UIKit
class Color{
    var description : String
    var color : String
    
    init(description: String, color: String) {
        self.description = description
        self.color = color
    }
}
