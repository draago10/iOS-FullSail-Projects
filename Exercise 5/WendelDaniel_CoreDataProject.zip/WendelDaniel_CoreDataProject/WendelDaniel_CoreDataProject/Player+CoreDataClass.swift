//
//  Player+CoreDataClass.swift
//  WendelDaniel_CoreDataProject
//
//  Created by Daniel Wendel on 6/24/21.
//
//

import Foundation
import CoreData

@objc(Player)
public class Player: NSManagedObject {

}
