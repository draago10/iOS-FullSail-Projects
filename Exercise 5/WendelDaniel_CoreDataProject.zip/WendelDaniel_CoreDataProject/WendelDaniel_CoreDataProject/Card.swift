//
//  Card.swift
//  WendelDanielAdaptiveLayoutProject
//
//  Created by Daniel Wendel on 6/7/21.
//

import UIKit

struct Card {
    var backImage : UIImage?
    var frontImage : UIImage?
}
